#!/bin/bash
cd /workspace
./setup_vastai.sh
./start_server.sh
